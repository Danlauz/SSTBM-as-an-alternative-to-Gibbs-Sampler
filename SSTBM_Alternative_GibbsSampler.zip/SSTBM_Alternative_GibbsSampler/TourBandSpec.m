function Z=TourBandSpec(nx,ny,nz,model,c,nl,nbsim)%zref,Pos

x0=grille3(1,nx,1,1,ny,1,1,nz,1);

%Y=anamor([x0,zref]);
%Yobs=Y(Pos,[1 2 3 5]);

%1- Calculation of f1(s) and F1
[F1,s,rot,cx]=DensSpec1Ddl(x0,model,c);

%matrix of covariance of observed data for the post-conditioning
%k=covardm(x0(Pos,:),x0(Pos,:),model,c);
%ki=inv(k);
%k0=covardm(x0(Pos,:),x0,model,c);

parfor j=1:nbsim
    ysim=cell(size(F1,2),1);
    for k=1:size(F1,2)
        ysim{k}=zeros(size(x0,1),1);
        rng('default')
        rng(j+nbsim*(k-1));
        
        %3-Random number between 0-1 and define ul
        % draw random probabilities
        p=rand(nl,1);
        ul1=interp1(F1{k},s{k},p); % interpolate ul from p and cum
        %4-Random number between 0-2pi
        U=2*pi*rand(nl,1);
        
        %5-random line generation
        z=VanCorput(nl);    % Van Corput sequence
        %6- scalar product of line z with density line ul
        z1=z.*ul1;
        for i=1:nl
            %7- Calculation of Z(x); repeat nl time
            ysim{k}=ysim{k}*sqrt((i-1)/i)+ sqrt(2/i)*sqrt(c(k))*cos((cx{k}(:,[1 2 3])*rot{k}')*z1(i,:)'+ U(i));
        end
        %clear U; clear ul1; clear z; clear zi; clear p;
    end
    %8- Zsim
    %ysim= postcond( Yobs , [x0(Pos,:) , ysim(Pos,:)], [x0(:,:) ,ysim] , 1 , ki ,k0 );
    
    %zfin=anamorinv(Y,ysim(:,end));
    %zsim=zfin(:,2);
    Z(:,j)=zeros(length(x0),1);
    for k=1:size(F1,2)
        Z(:,j)=Z(:,j)+ysim{k}; %zsim;
    end
end
