%%%%WORKPLACE%%%%
%%Ex1 Truncated Gaussian
clear variables
nx=100; ny=100; nz=1;
nbsim=50;
nl=1000; nlmax=200000;
model=[6 40 40 1 0 0 0]; c=1; %synthetique spec

zref=TourBandSpec(nx,ny,nz,model,c,nl,nbsim);
Pos=(1:1:nx*ny*nz)';
seuil=[0  0.3 0.5  1];
facies=[1 2 3];

zIND=zeros(nx*ny*nz,nbsim);
alpha=zeros(nx*ny*nz,nbsim);
beta=zeros(nx*ny*nz,nbsim);
for i=1:nbsim
    z=ones(nx*ny*nz,1);
    bet=NaN(nx*ny*nz,1);
    alp=NaN(nx*ny*nz,1);
    for j=1:length(facies)
        z(zref(:,i)>=quantile(zref(:,i),seuil(j)))=facies(j);
        alp(zref(:,i)>=quantile(zref(:,i),seuil(j)))=norminv(seuil(j));
        bet(zref(:,i)>=quantile(zref(:,i),seuil(j)))=norminv(seuil(j+1));
    end
    zIND(:,i)=z;
    alpha(:,i)=alp;
    beta(:,i)=bet;
end
[Y,itt,YNoSGS]=TruncatedGaussianSSTBM(nx,ny,nz,model,c,nl,nlmax,nbsim,Pos,alpha,beta);

figureSSTBM_TGS
