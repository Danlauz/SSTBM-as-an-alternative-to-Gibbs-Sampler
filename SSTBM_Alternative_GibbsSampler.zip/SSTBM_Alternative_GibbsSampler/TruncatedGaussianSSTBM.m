function [Y,itt,YNoSGS]=TruncatedGaussianSSTBM(nx,ny,nz,model,c,nlmin,nlmax,nbsim,Pos,LowerBounds,UpperBounds)
%nx,ny,nz : dimension of the grid (nx X ny X nz).
%model : covariance model used
%c : sill
%nlmin and nlmax : minimum and maximum of cosines functions generated.
%nbsim : numbers of simulations performed.
%Pos : location of hard data (here, observed facies) (size : nx*ny*nz X nbsim)
%LowerBounds : lower inequality bounds vector (size : nx*ny*nz X nbsim)
%UpperBounds : upper inequality bounds vector (size : nx*ny*nz X nbsim)
if nlmax<nlmin || nlmax<1000
    error('1) nlmax must be equal or greater than nlmin. 2) nlmax must be equal or greater than 1000.')
end
if nlmin<1000
    error('nlmin must be equal or grater than 1000.')
end
if (round(nx)~= nx && nx <= 0) || (round(ny)~= ny && ny <= 0)|| (round(nz)~= nz && nz <= 0)
    error('nx, ny and nz must be positive integers.')
end

%0- Regular grid generation
x0=grille3(1,nx,1,1,ny,1,1,nz,1);
%1- Computation of the one-dimensional spectral density F1
[F1,s,rot,cx]=DensSpec1Ddl(x0,model,c);
%2-Random number between 0-1 and define ul
% draw random probabilities
ul1=zeros(max(1000,nlmax),size(F1,2));
for k=1:size(F1,2)
    p=rand(nlmax,1);
    ul1(1:nlmax,k)=interp1(F1{k},s{k},p); % interpolate ul from p and cum
end
%3-random line generation (Van Corput sequence)
z=VanCorput(nlmax);

%4- scalar product of line z with density line ul
z1=cell(2,1);
for k=1:size(F1,2)
    z1{k}=ul1(1:nlmax,k).*z;
end

%Generate nbsim GRF subject to inequality constraints
Y=zeros(length(x0),nbsim);
itt=zeros(nbsim,1);
YNoSGS=zeros(length(x0),nbsim);
parfor j=1:nbsim
    rng('default')
    rng(j);
    %Inequality constraints
    alpha=LowerBounds(:,j);
    beta=UpperBounds(:,j);
   
    y=cell(size(rot,2),1);ysim=zeros(length(x0),1);
    for k=1:size(rot,2)
        y{k}=zeros(length(x0),1);
    end
    ysimNoSGS=zeros(size(x0,1),1);
    ittfinal=[];
    misfit=max(alpha(Pos,:)-ysim(Pos),0)+max(ysim(Pos)-beta(Pos,:),0);
    %iterative step on each cosine function i
    i=0;
    while (i< nlmin || mean(misfit) > 0) && i<nlmax        
        if (i < nlmin || mean(misfit)>0.0005) && i<nlmax-1 %S-STBM
            i=i+1;
            options=optimset('MaxIter',5,'TolX',10^-8,'Display','off');
            func = @(Uopt) OptErr(y,Uopt,c,cx,rot,z1,alpha,beta,i,Pos);
            [Uopt] = fminbnd(func, 0, 1,options);
            ysim=zeros(length(x0),1);
            for k=1:size(rot,2)
                y{k}= y{k}*sqrt((i-1)/i)+ sqrt(2/i)*sqrt(c(k))*cos((cx{k}(:,[1 2 3])*rot{k}')*z1{k}(i,:)'+ 2*pi*Uopt);
                ysim=ysim+y{k};
            end
            misfit=max(alpha(Pos,:)-ysim(Pos),0)+max(ysim(Pos)-beta(Pos,:),0);
            ysimNoSGS=ysim;
            ittfinal=i;
        else %T-SGS
            %ramdomly chose an unconstrained nodes
            indUnC=randsample(Pos(misfit>0),1);
            %find the closest constrained neighbors from a neighborhood of radius 5
            Idx=knnsearch(x0,x0(indUnC,:),'K',81)';
            Idx=Idx(misfit(Idx)==0);
            %Resolve the kriging system
            [ZKS,SigKS]=KrigingS(ysim(Idx),x0(Idx,:),x0(indUnC,:),model,c);
            %Accept the kriging value or draw a value from a truncated conditional distribution 
            if (max(alpha(indUnC)-ZKS,0)+max(ZKS-beta(indUnC),0))==0
                ysim(indUnC)=ZKS;
            else
                N=trandn((alpha(indUnC)-ZKS)/SigKS,(beta(indUnC)-ZKS)/SigKS);
                ysim(indUnC)=ZKS+N*SigKS;
            end
            misfit=max(alpha(Pos,:)-ysim(Pos),0)+max(ysim(Pos)-beta(Pos,:),0);
            if sum(misfit>0)==0
                i=nlmax;
            end
        end
        
    end
    Y(:,j)=ysim;
    itt(j)=ittfinal;
    YNoSGS(:,j)=ysimNoSGS;
    j
end


function [error]=OptErr(ysim,U,c,cx,rot,z1,alpha,beta,j,Pos)
for k=1:size(rot,2)
    ysim{k}=ysim{k}*sqrt((j-1)/j)+ sqrt(2/j)*sqrt(c(k))*cos((cx{k}(:,[1 2 3])*rot{k}')*z1{k}(j,:)'+ 2*pi*U);
end
y=zeros(length(ysim{1}),1);
for k=1:size(rot,2)
    y=y+ysim{k};
end
err=max(alpha(Pos,:)-y(Pos),0)+max(y(Pos)-beta(Pos,:),0);
error=mean(err);

function [ZKS,SigKS]=KrigingS(Z,x0,xi,model,c)
%Z: hard data
%x0: Position of the hard data
%xi: Position of estimation point

k=covardm(x0,x0,model,c);
k0=covardm(x0,xi,model,c);
lamda= k\k0;
ZKS=sum(lamda.*Z);
SigKS=sqrt(sum(c)-lamda'*k0);