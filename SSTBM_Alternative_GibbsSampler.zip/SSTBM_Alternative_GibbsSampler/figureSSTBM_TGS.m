%Reference
yIND=zeros(nx*ny*nz,nbsim);
for i=1:nbsim
    y=zeros(nx*ny*nz,1);
    k=1;
    for j=1:length(facies)
        y(Y(:,i)>=norminv(seuil(j)))=facies(j);
        k=k+1;
    end
    yIND(:,i)=y;
end
numSim=1;
figure(1)
imagesc(reshape(Y(:,numSim),[nx,ny]))
colorbar()
colormap('summer');
set(gca,'YDir','normal')
caxis([-3 3])
title('TGS :SSTBM simulation')
figure(2)
imagesc(reshape(zref(:,numSim),[nx,ny]))
colorbar()
caxis([-3 3])
colormap('summer');
set(gca,'YDir','normal')
title('TGS :Reference')
figure(3)
imagesc(reshape(yIND(:,numSim),[nx,ny]))
colormap('summer');
colorbar()
set(gca,'YDir','normal')
title('TGS :SSTBM simulation (facies field)')
figure(4)
imagesc(reshape(zIND(:,numSim),[nx,ny]))
colormap('summer');
colorbar()
set(gca,'YDir','normal')
title('TGS :Reference (facies field)')
figure(5)
imagesc(reshape(abs(zIND(:,numSim)-yIND(:,numSim)),[nx,ny]))
colorbar()
set(gca,'YDir','normal')
title('TGS :All nodes are constrained')

%Variogram
x0=grille3(1,nx,1,1,ny,1,1,nz,1);
[VarSim]=varioFFT2D_dl( x0(:,[1 2]) , Y , 1 , 0 , 0 );
VarRef=reshape(c-covardm(x0,[1 1 1],model,c),[nx ny]);
varRefx=VarRef(1,:);
varRefy=VarRef(:,1);

dimx=nx; dimy=ny;

figure(6)
meanvarSim1=0;
for i=1:nbsim
    plot([0 : ny-1],VarSim{i,i}(nx,ny:2*ny-1),'Color',[0.9,0.9,0.9])
    hold on;
    meanvarSim1=meanvarSim1+VarSim{i,i}(nx,ny:2*ny-1)/nbsim;    
end
p1=plot([0 : ny-1],meanvarSim1,'*b');
hold on
plot([0 : ny-1],varRefx,'k')

xlabel('Lag separation distance')
ylabel('Variogram value')
ylim([0  1.2])
xlim([1  ny/2])
title('TGS : Var X')
figure(7)
meanvarSim1=0;
meanvarSim2=0;
for i=1:nbsim
    plot([0 : nx-1],VarSim{i,i}(nx:2*nx-1,ny),'Color',[0.9,0.9,0.9])
    hold on
    meanvarSim1=meanvarSim1+VarSim{i,i}(nx:2*nx-1,ny)/nbsim;
end
p1=plot([0 : nx-1],meanvarSim1,'*b');
hold on
plot([0 : ny-1],varRefy,'k')


xlabel('Lag separation distance')
ylabel('Variogram value')
ylim([0  1.5])
xlim([1  ny/2])
title('TGS : Var Y')
figure(8)
plot(itt,'*')
xlabel('simulation #')
ylabel('nb of cosine function generated')
title('TGS : iterative step')