%% 2) 100x100 Truncated Gaussian simulation
clear all
nx=100; ny=100; nz=1;
nbsim=20;
model{1}=[6 40 40 1 0 0 0]; c{1}=1; rho={}; beta=[0]; alpha=[0 0 0];
x0=grille3(1,nx,1,1,ny,1,1,1,1);
nl=2000; nlmax=200000;
Pos=(1:1:nx*ny*nz)';

alphamin=min(min(alpha,[],1),[0 0 0]);
alphamax=max(max(alpha,[],1),[0 0 0]);
nxa=nx+(alphamax(1)-alphamin(1));
nya=ny+(alphamax(2)-alphamin(2));
nza=nz+(alphamax(3)-alphamin(3));
x0Pos=(1:1:nxa*nya*nza)';
x0Pos=reshape(x0Pos,[nxa ,nya ,nza]);
x0Pos=reshape(x0Pos(  abs(alphamin(1))+1:1:abs(alphamin(1))+max(x0(:,1)) , abs(alphamin(2))+1:1:abs(alphamin(2))+max(x0(:,2)) , abs(alphamin(3))+1:1:abs(alphamin(3))+max(x0(:,3)) ),[],1);
x0Corr=alpha(:,1)+nxa*alpha(:,2)+nxa*nya*alpha(:,3);

ZA=cell(1,length(model)); Zref=cell(1,nbsim);
YA=cell(1,length(model));Yref=cell(1,nbsim);

for k=1:length(model)
    YA{k}=TourBandSpec(nxa,nya,nza,model{k},c{k},nl,nbsim,k,0);
    YA2{k}=TourBandSpec(nxa,nya,nza,model{k},c{k},nl,nbsim,2000+k,0);
    if k==1
        ZA{k}(:,:)=YA{k}(x0Pos,:);
    else
        betasum=0; idx=(k-1)*(k-2)/2+1; ZA{k}=zeros(nx*ny*nz,nbsim);
        for kk=1:k-1
            betasum=betasum+beta(idx)^2;
            loc=x0Pos+x0Corr(idx);
            ZA{k}(:,:)=ZA{k}(:,:)+beta(idx)*YA{kk}(loc,:);
            idx=idx+1;
        end
        ZA{k}=ZA{k}+sqrt(1-betasum)*YA{k}(x0Pos,:);
    end
end

for k=1:length(model)
    for j=1:nbsim
        Zref{j}(:,k)=ZA{k}(:,j);
        Yref{j}(:,k)=YA{k}(x0Pos,j);
        Zref2{j}(:,k)=YA2{k}(x0Pos,j);
    end
end

clear ZA; clear YA; clear YA2; clear idx; clear loc; clear x0Pos; clear x0Corr;
clear nxa; clear nya; clear nza; clear alphamin; clear alphamax; clear betasum;
clear k; clear kk;

for i=1:nbsim
   seuil=[1  0.00 0.50  ;...
          2  0.50 1.00  ]; 
   zind=PluriGaussianTransformRef(Zref,seuil,nbsim);
end

for j=1:nbsim
    for i=1:size(seuil,1)
        for k=1:length(model)
            idx=(zind(:,j)==seuil(i,1));
            l(idx,k)=norminv(seuil(i,2*k));
            u(idx,k)=norminv(seuil(i,2*k+1));
        end
    end
    threshold.low=l;
    threshold.up=u;
    bounds{j}=threshold;
end
for j=1:nbsim
    varinit{j}=cov(Zref2{j},1);
end
clear threshold; clear l; clear u; clear i; clear j; clear k; clear idx;
