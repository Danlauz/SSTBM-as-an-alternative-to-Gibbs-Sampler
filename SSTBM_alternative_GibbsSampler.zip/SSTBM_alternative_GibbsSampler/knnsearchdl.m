function [Idx]=knnsearchdl(X,Y,Pos,nbN)
%Finds the nbN nearest neighbors in X for the point Y and returns the indices of the neighborhood in Idx.

dist=sqrt(sum((X(:,:)-Y).^2,2));
[sortdist,Idx]=sort(dist);
Idx=Idx(1:min(length(Idx),nbN));
Idx=Pos(Idx);
