function [Zsim,ZNoSGS,itt]=PluriGaussianSSTBM(nx,ny,nz,model,c,rho,alpha,nl,nlmax,nbsim,Pos,bounds,gpuOn,VARinit)
x01=grille3(1,nx,1,1,ny,1,1,nz,1);

alphamin=min(min(alpha,[],1),[0 0 0]);
alphamax=max(max(alpha,[],1),[0 0 0]);
nx=nx+(alphamax(1)-alphamin(1));
ny=ny+(alphamax(2)-alphamin(2));
nz=nz+(alphamax(3)-alphamin(3));
x0Pos=(1:1:nx*ny*nz)';
x0Pos=reshape(x0Pos,[nx ,ny ,nz]);

x0Pos=reshape(x0Pos(  abs(alphamin(1))+1:1:abs(alphamin(1))+max(x01(:,1)) , abs(alphamin(2))+1:1:abs(alphamin(2))+max(x01(:,2)) , abs(alphamin(3))+1:1:abs(alphamin(3))+max(x01(:,3)) ),[],1);

x0Corr=cell(size(alpha,1),1);
for k=1:size(alpha,1)
    x0Corr{k}=x0Pos+(alpha(k,1)+nx*alpha(k,2)+nx*ny*alpha(k,3));
end
clear alphamin; clear alphamax;
%Grid
x02=grille3(1,nx,1,1,ny,1,1,nz,1);
%1- Calculation of f1(s) and F1 for the 'k' model
DS1D=cell(length(model),1);
for k=1:length(model)
    DS1D{k}=DensSpec1Ddl(x02,model{k},c{k});
    if gpuOn
        for kk=1:length(DS1D{k}.Fds1)
            DS1D{k}.Rrot{kk}  =  gpuArray(DS1D{k}.Rrot{kk}');
            DS1D{k}.cxrot{kk} =  gpuArray(DS1D{k}.cxrot{kk});
        end
    else
        for kk=1:length(DS1D{k}.Fds1)
            DS1D{k}.Rrot{kk}  =  DS1D{k}.Rrot{kk}';
        end
    end
end
%j simulation
for j=1:nbsim  %parfor
    rng('default')
    rng(j);
    %Inequality constraints
    thresholdj= bounds{j};
    varinit=VARinit{j};
    if gpuOn==1
        varinit=gpuArray(varinit);
    end
    %Initialization of each parameters
    lowbound=cell(length(model),1);  upbound=cell(length(model),1);
    %Compute the frequency Vector from a Van Corput sequence
    Z=frequencyVector(model,DS1D,nl,nlmax,gpuOn);
    for k=1:length(model)               
        if gpuOn
            lowbound{k}=gpuArray(thresholdj.low(:,k)); upbound{k}=gpuArray(thresholdj.up(:,k));
        else
            lowbound{k}=thresholdj.low(:,k);    upbound{k}=thresholdj.up(:,k);
        end
    end
    if gpuOn
        error=gpuArray(NaN(size(x01,1),length(model))); error(Pos,:)=gpuArray(ones(size(x01(Pos,:),1),length(model)));
        misfit=gpuArray(NaN(size(x01,1),1)); misfit(Pos)=gpuArray(sqrt(sum(error(Pos,:).^2,2)));
        ysim=gpuArray(zeros(length(x02),length(model)));      zsim=gpuArray(zeros(length(x01),length(model)));
        ysimNoSGS=gpuArray(zeros(length(x02),length(model))); zsimNoSGS=gpuArray(zeros(length(x01),length(model)));
    else
        error=NaN(size(x01,1),length(model)); error(Pos,:)=ones(size(x01(Pos,:),1),length(model));
        misfit=NaN(size(x01,1),1); misfit(Pos)=sqrt(sum(error(Pos,:).^2,2));
        ysim=zeros(length(x02),length(model));      zsim=zeros(length(x01),length(model));
        ysimNoSGS=zeros(length(x02),length(model)); zsimNoSGS=zeros(length(x01),length(model));
    end
    %Optimization
    i=0; ii=0;
    while (i<nl) || (i<nlmax && sum(misfit(Pos)>0)>0)
        %S-STBM
       
        MeanError=mean(misfit(Pos))>0.001;        
        if  (i < nl || MeanError ) && i<nlmax-1
            i=i+1;
            if mod(i,1000)==0
                i
            end
            [ysim,zsim]=PhaseOptimization(ysim,zsim,DS1D,Z,i,lowbound,upbound,Pos,rho,c,varinit,x0Pos,x0Corr,gpuOn);
            %Error
            for k=1:length(model)
                error(Pos,k)=(max(lowbound{k}(Pos)-zsim(Pos,k),0)+max(zsim(Pos,k)-upbound{k}(Pos),0));
                zsimNoSGS(:,k)=zsim(:,k);
                ysimNoSGS(:,k)=ysim(:,k);
                ii=i;
            end
            misfit(Pos)=sqrt(sum(error(Pos,:).^2,2));
            %T-SGS
        else
            [ysim,zsim,error,misfit]=TSGS(x02,Pos,ysim,zsim,model,c,rho,lowbound,upbound,error,misfit,x0Pos,x0Corr);
            if sum(misfit(Pos)>0)==0
                i=nlmax;
            end
        end
    end
    if gpuOn
        zsim=gather(zsim);
        zsimNoSGS=gather(zsimNoSGS);
    end
    Zsim{j}=zsim;
    ZNoSGS{j}=zsimNoSGS;
    itt(j)=ii;
    j
end

function [Z]=frequencyVector(model,DS1D,nl,nlmax,gpuOn)
Z=cell(length(model),1);
ul=cell(length(model),1);
z=cell(length(model),1);
for k=1:length(model)
    %2-Random number between 0-1 and define ul
    % draw random probabilities for both model
    for kk=1:size(DS1D{k}.Fds1,2)
        p=rand(max(nl,nlmax),1);
        ul{k}(:,kk)=interp1(DS1D{k}.Fds1{kk},DS1D{k}.S{kk},p); % interpolate ul from p and cum
    end
    %3-random line generation for both model (method : Van Corput)
    z{k}=VanCorput(max(nl,nlmax));
    %4- scalar product of line z with density line ul for both model
    for kk=1:size(DS1D{k}.Fds1,2)
        if gpuOn
            Z{k}{kk}=(gpuArray(ul{k}(:,kk)).*gpuArray(z{k}))';
        else
            Z{k}{kk}=(ul{k}(:,kk).*z{k})';
        end
    end
end

function [ysim,zsim]=PhaseOptimization(ysim,zsim,DS1D,Z,i,lowbound,upbound,Pos,rho,c,varinit,x0Pos,x0Corr,gpuOn)
for k=1:length(c)
    options=optimset('MaxIter',5,'TolX',10^-8,'Display','off');
    func = @(Uopt) OptErr(ysim,zsim,Uopt,c,DS1D,Z,i,lowbound,upbound,Pos,rho,varinit,x0Pos,x0Corr,k);
    [Uopt]= fminbnd(func,0,1,options);
    if gpuOn==1
        Uopt=gpuArray(Uopt);
    end
    ysim(:,k)=ysim(:,k)*sqrt(i-1);
    for kk=1:size(DS1D{k}.Rrot,2)
        ysim(:,k)= ysim(:,k)+sqrt(2)*sqrt(c{k}(kk))*cos((DS1D{k}.cxrot{kk}(:,[1 2 3])*DS1D{k}.Rrot{kk})*Z{k}{kk}(:,i)+ 2*pi*Uopt);
    end
    ysim(:,k)=ysim(:,k)*sqrt(1/i);
    if k==1
        zsim(:,k)=ysim(x0Pos,k);
    elseif k>1
        beta=0; zsim(:,k)=0; idx=(k-2)*(k-3)/2+k-1;
        for kk=1:k-1
            beta=beta+rho(idx)^2;
            zsim(:,k)=zsim(:,k)+rho(idx)*ysim(x0Corr{idx},kk);
            idx=idx+1;
        end
        zsim(:,k)=zsim(:,k)+sqrt(1-beta)*ysim(x0Pos,k);
    end
end

function [error]=OptErr(ysim,zsim,U,c,DS1D,Z,i,lowbound,upbound,Pos,rho,varinit,x0Pos,x0Corr,k) 
ysim(:,k)=ysim(:,k)*sqrt(i-1);
for kk=1:size(DS1D{k}.Rrot,2)
         ysim(:,k)=ysim(:,k)+sqrt(2)*sqrt(c{k}(kk))*cos((DS1D{k}.cxrot{kk}(:,[1 2 3])*DS1D{k}.Rrot{kk})*Z{k}{kk}(:,i)+ 2*pi*U);
end
ysim(:,k)=ysim(:,k)*sqrt(1/i);

if k==1
    zsim(:,k)=ysim(x0Pos,k);
elseif k>1
    beta=0; idx=(k-2)*(k-3)/2+k-1; zsim(:,k)=0;
    for kk=1:k-1
        beta=beta+rho(idx)^2;
        zsim(:,k)=zsim(:,k)+rho(idx)*ysim(x0Corr{idx},kk);
        idx=idx+1;
    end
    zsim(:,k)=zsim(:,k)+sqrt(1-beta)*ysim(x0Pos,k);
end

err=mean(max(lowbound{k}(Pos)-zsim(Pos,k),0)+max(zsim(Pos,k)-upbound{k}(Pos),0));

varall=abs(varinit-cov(zsim,1));
varall=mean(varall(:,k),'all');
error=500*err + 1*varall;


function [ysim,zsim,error,misfit]=TSGS(x02,Pos,ysim,zsim,model,c,beta,lowbound,upbound,error,misfit,x0Pos,x0Corr)
if length(Pos(misfit(Pos)>0))>1
    indzsim=randsample(Pos(misfit(Pos)>0),1);
    indysim=x0Pos(indzsim);
elseif length(Pos(misfit(Pos)>0))==1
    indzsim=Pos(misfit(Pos)>0);
    indysim=x0Pos(indzsim);
end
IdxCons=Pos(misfit==0);
Idxzsim = knnsearchdl(Pos(IdxCons,:),Pos(indzsim,:),IdxCons,82);
Idxysim=x0Pos(Idxzsim);
for k=1:length(model)
    [ZKS,SigKS]=KrigingS(ysim(Idxysim,k),x02(Idxysim,:),x02(indysim,:),model{k},c{k});
    low=lowbound{k}(indzsim); up=upbound{k}(indzsim);
    if k==1
        crit1=(max(low-ZKS,0)+max(ZKS-up,0));
        crit2=(max(low-ysim(indysim,k),0)+max(ysim(indysim,k)-up,0));
        if (crit1==0) && (crit2~=0)
            ysim(indysim,k)=ZKS;
        elseif (crit2~=0)
            N=trandn(gather((low-ZKS)/SigKS),gather((up-ZKS)/SigKS));
            ysim(indysim,k)=ZKS+N*SigKS;
        end
        zsim(indzsim,k)=ysim(indysim,k);
    elseif k>1
        betasum=0; zsim(indzsim,k)=0; idx=(k-2)*(k-3)/2+k-1;
        for kk=1:k-1
            betasum=betasum+beta(idx)^2;
            zsim(indzsim,k)=zsim(indzsim,k)+beta(idx)*ysim(x0Corr{idx}(indzsim),kk);
            idx=idx+1;
        end
        zsimMidTerm=zsim(indzsim,k);
        zsim(indzsim,k)=zsim(indzsim,k)+sqrt(1-betasum)*ysim(indysim,k);
        crit1=max(low-(zsimMidTerm+sqrt(1-betasum)*ZKS),0)+max((zsimMidTerm+sqrt(1-betasum)*ZKS)-up,0);
        crit2=max(low-zsim(indzsim,k),0)+max(zsim(indzsim,k)-up,0);
        if crit1==0 && crit2~=0
            ysim(indysim,k)=ZKS;
            zsim(indzsim,k)=zsimMidTerm+sqrt(1-betasum)*ZKS;
        elseif crit2~=0
            N=trandn(gather(((low-zsimMidTerm)/sqrt(1-betasum)-ZKS)/SigKS) ,gather(((up-zsimMidTerm)/sqrt(1-betasum)-ZKS)/SigKS));
            ysim(indysim,k)=ZKS+N*SigKS;
            zsim(indzsim,k)=zsimMidTerm+sqrt(1-betasum)*ysim(indysim,k);
        end
    end
    error(indzsim,k)=0;
end
misfit(indzsim)=0;

function [ZKS,SigKS]=KrigingS(Z,x0,xi,model,c)
%Z: hard data
%x0: Position of the hard data
%xi: Position of estimation point

k=covardm(x0,x0,model,c);
k0=covardm(x0,xi,model,c);
lamda= k\k0;
ZKS=sum(lamda.*Z);
SigKS=sum(c)-lamda'*k0;

