function [V,x0]=DiagramsPluriGaussian(seuil,spacingX,spacingY)
x0=grille2(spacingX,1,spacingX,spacingY,1,spacingY);
V=zeros(length(x0),1);

for i=1:size(seuil,1)
    a{1,i}(:,1)=x0(:,1)>seuil(i,2);
    a{1,i}(:,2)=x0(:,2)>seuil(i,4);
    a{1,i}(:,3)=x0(:,1)<=seuil(i,3);
    a{1,i}(:,4)=x0(:,2)<=seuil(i,5);
    a{1,i}(:,5)=double(a{1,i}(:,1)).*double(a{1,i}(:,2)).*double(a{1,i}(:,3)).*double(a{1,i}(:,4));
    V(a{1,i}(:,5))=seuil(i,1);
end