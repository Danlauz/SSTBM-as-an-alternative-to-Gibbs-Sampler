function [zind]=PluriGaussianTransformRef(Z,seuil,nbsim)

nbfacies=max(seuil(:,1));
zind=zeros(size(Z{1},1),nbsim);
l=zeros(size(Z{1}));
u=zeros(size(Z{1}));
for j=1:nbsim
    for i=1:nbfacies
        for k=1:size(Z{1},2)
            l(:,k)= double(Z{j}(:,k)>=norminv(seuil(i,2*k)));
            u(:,k)= double(Z{j}(:,k)<norminv(seuil(i,2*k+1)));
        end
        log=logical(prod(l,2).*prod(u,2));
        zind(log,j)=seuil(i,1);
    end   
end

