%% Truncated Gaussian Simulation (ten simulations)
clear all
TGS

[Z,ZNoSGS,itt]=PluriGaussianSSTBM(nx,ny,nz,model,c,beta,alpha,nl,nlmax,nbsim,Pos,bounds,0,varinit);
ZIND=PluriGaussianTransform(Z,seuil,nbsim);

Figures
%% Pluri-Gaussian Simulation (Ten simulations)
clear all
PGS                
[Z,ZNoSGS,itt]=PluriGaussianSSTBM(nx,ny,nz,model,c,beta,alpha,nl,nlmax,nbsim,Pos,bounds,0,varinit);
ZIND=PluriGaussianTransform(Z,seuil,nbsim);
Figures