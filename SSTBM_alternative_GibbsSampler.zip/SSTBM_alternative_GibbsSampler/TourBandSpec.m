function Z=TourBandSpec(nx,ny,nz,model,c,nl,nbsim,seed,gpuOn)%zref,Pos

x0=grille3(1,nx,1,1,ny,1,1,nz,1);

%Y=anamor([x0,zref]);
%Yobs=Y(Pos,[1 2 3 5]);

%1- Calculation of f1(s) and F1
DS1D=DensSpec1Ddl(x0,model,c);
if gpuOn==1
    for k=1:length(DS1D.Fds1)
        DS1D.Fds1{k}  =  gpuArray(DS1D.Fds1{k});
        DS1D.S{k}     =  gpuArray(DS1D.S{k});
        DS1D.Rrot{k}  =  gpuArray(DS1D.Rrot{k}');
        DS1D.cxrot{k} =  gpuArray(DS1D.cxrot{k});
    end
else
    for k=1:length(DS1D.Fds1)
        DS1D.Rrot{k}  =  DS1D.Rrot{k}';
    end
end
F1=DS1D.Fds1;
s=DS1D.S;
rot=DS1D.Rrot;
cx=DS1D.cxrot;

if gpuOn==1
    Z=zeros(length(x0),nbsim,'gpuArray');
else
    Z=zeros(length(x0),nbsim);
end
parfor j=1:nbsim
    ysim=cell(size(F1,2),1);
    for k=1:size(F1,2)
        if gpuOn==1
            ysim{k}=zeros(size(x0,1),1,'gpuArray');
        else
            ysim{k}=zeros(size(x0,1),1);
        end
        rng('default')
        rng(100*seed*(j+nbsim*(k-1)));
        
        %3-Random number between 0-1 and define ul
        % draw random probabilities
        p=rand(nl,1);
        ul1=interp1(gather(F1{k}),gather(s{k}),p); % interpolate ul from p and cum
        %4-Random number between 0-2pi
        if gpuOn==1
            U=2*pi*rand(nl,1,'gpuArray');
        else
            U=2*pi*rand(nl,1);
        end
        
        %5-random line generation
        % Van Corput sequence
        if gpuOn==1
            z=gpuArray(VanCorput(nl));
        else
            z=VanCorput(nl);
        end
        %6- scalar product of line z with density line ul
        if gpuOn==1
            z1=gpuArray((z.*ul1)');
        else
            z1=(z.*ul1)';
        end
        
        for i=1:nl
            %7- Calculation of Z(x); repeat nl time
            ysim{k}=ysim{k}*sqrt((i-1)/i)+ sqrt(2/i)*sqrt(c(k))*cos((cx{k}(:,[1 2 3])*rot{k})*z1(:,i)+ U(i));
        end
        %clear U; clear ul1; clear z; clear zi; clear p;
    end
    %8- Zsim
    for k=1:size(F1,2)
        Z(:,j)=Z(:,j)+ysim{k}; %zsim;
    end
end
Z=gather(Z);