
x0=grille3(1,nx,1,1,ny,1,1,1,1);
VarSim=cell(1,nbsim);
for i=1:nbsim
    VarSim{i}=varioFFT2D_dl( x0(:,[1 2 3]) , Z{i} , 1 , 0 , 0 );
end

VarRef=cell(1,length(model)); VarRefx=cell(1,length(model)); VarRefy=cell(1,length(model));
x0x=grille3(1,1,1,-ny+2,ny,1,1,1,1);
x0y=grille3(-nx+2,nx,1,1,1,1,1,1,1);
for k=1:length(model)
    VarRefx{k}=reshape(c{k}-covardm(x0x,[1 1 1],model{k},c{k}),[2*nx-1,1]);
    VarRefy{k}=reshape(c{k}-covardm(x0y,[1 1 1],model{k},c{k}),[2*ny-1,1]);
end
for k=1:size(alpha,1)
    if k<2
        a=1;
    elseif k==3
        a=2;
    end
    CovRefxhplus{k}=reshape(covardm(x0x+alpha(k,:),[1 1 1],model{a},c{a}),[2*nx-1,1]);
    CovRefxhmoins{k}=reshape(covardm((x0x*-1+2)+alpha(k,:),[1 1 1],model{a},c{a}),[2*nx-1,1]);
    CovRefxhorigine{k}=reshape(covardm([1 1 1]+alpha(k,:),[1 1 1],model{a},c{a}),[1,1]);
    %VarRefxalpha{k}=(CovRefxhorigine{k}-0.5*(CovRefxhplus{k}+CovRefxhmoins{k}));
    VarRefxalphaP{k}=CovRefxhplus{k};
    VarRefxalphaM{k}=CovRefxhmoins{k};
    CovRefyhplus{k}=reshape(covardm(x0y+alpha(k,:),[1 1 1],model{a},c{a}),[2*ny-1,1]);
    CovRefyhmoins{k}=reshape(covardm((x0y*-1+2)+alpha(k,:),[1 1 1],model{a},c{a}),[2*ny-1,1]);
    CovRefyhorigine{k}=reshape(covardm([1 1 1]+alpha(k,:),[1 1 1],model{a},c{a}),[1,1]);
    %VarRefyalpha{k}=(CovRefxhorigine{k}-0.5*(CovRefyhplus{k}+CovRefyhmoins{k}));
    VarRefyalphaP{k}=CovRefyhplus{k};
    VarRefyalphaM{k}=CovRefyhmoins{k};
end
if size(model,2)==3
    CovRefxhplus{4}=reshape(covardm(x0x+alpha(2,:)-alpha(1,:),[1 1 1],model{1},c{1}),[2*nx-1,1]);
    CovRefxhmoins{4}=reshape(covardm((x0x*-1+2)+alpha(2,:)-alpha(1,:),[1 1 1],model{1},c{1}),[2*nx-1,1]);
    CovRefxhorigine{4}=reshape(covardm([1 1 1]+alpha(2,:)-alpha(1,:),[1 1 1],model{1},c{1}),[1,1]);
    %VarRefxalpha{4}=(CovRefxhorigine{4}-0.5*(CovRefxhplus{4}+CovRefxhmoins{4}));
    VarRefxalphaP{4}=CovRefxhplus{4};
    VarRefxalphaM{4}=CovRefxhmoins{4};
    
    CovRefyhplus{4}=reshape(covardm(x0y+alpha(2,:)-alpha(1,:),[1 1 1],model{1},c{1}),[2*ny-1,1]);
    CovRefyhmoins{4}=reshape(covardm((x0y*-1+2)+alpha(2,:)-alpha(1,:),[1 1 1],model{1},c{1}),[2*ny-1,1]);
    CovRefyhorigine{4}=reshape(covardm([1 1 1]+alpha(2,:)-alpha(1,:),[1 1 1],model{1},c{1}),[1,1]);
    %VarRefyalpha{4}=(CovRefyhorigine{4}-0.5*(CovRefyhplus{4}+CovRefyhmoins{4}));
    VarRefyalphaP{4}=CovRefyhplus{4};
    VarRefyalphaM{4}=CovRefyhmoins{4};
end

jj=0;
meanvarSim=cell(length(model),length(model));
jj=jj+1;
figure(jj)
for k=1:length(model)
    for kk=1:length(model)
        subplot(length(model),length(model),kk+(k-1)*length(model),'align')
        meanvarSim{k,kk}=zeros(1,ny*2-1);
        for i=1:nbsim
            plot([-ny+1 :1: ny-1],VarSim{1,i}{k,kk}(nx,:),'Color',[0.9,0.9,0.9])
            hold on;
            meanvarSim{k,kk}=meanvarSim{k,kk}+(VarSim{i}{k,kk}(nx,:)+VarSim{i}{k,kk}(:,ny)')/2/nbsim;
        end

        if k==1 && kk==1
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],VarRefx{k},'k')
            hold on
            title('Cx_1_1')
        end
        if k==2 && kk==2
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],(beta(1))^2*VarRefx{1}+(1-(beta(1))^2)*VarRefx{2},'k')
            hold on
            title('Cx_2_2')
        end
        if k==1 && kk==2
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],beta(1)*VarRefxalphaP{1},'k')
            hold on
            title('Cx_1_2')
        end
        if k==2 && kk==1
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],beta(1)*VarRefxalphaM{1},'k')
            hold on
            title('Cx_2_1')
        end
        if k==3 && kk==3
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],beta(2)^2*VarRefx{1}+beta(3)^2*VarRefx{2}+(1-beta(2)^2-beta(3)^2)*VarRefx{3},'k')
            hold on
            title('Cx_3_3')
        end
        if k==1 && kk==3
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],(beta(2))*VarRefxalphaP{2},'k')
            hold on
            title('Cx_1_3')
        end
        if k==3 && kk==1
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],(beta(2))*VarRefxalphaM{2},'k')
            hold on
            title('Cx_3_1')
        end
        if k==2 && kk==3
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],beta(2)*beta(1)*VarRefxalphaP{4}+beta(3)*(1-(beta(1))^2)*VarRefxalphaP{3},'k')
            title('Cx_2_3')
        end
        if k==3 && kk==2
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],beta(2)*beta(1)*VarRefxalphaM{4}+beta(3)*(1-(beta(1))^2)*VarRefxalphaM{3},'k')
            title('Cx_3_2')
        end
        xlabel('Lag separation distance')
        ylabel('Variogram value')
        if k==kk
            ylim([0  1.5])
        else
            ylim([-0.25  0.75])
        end
        xlim([0  0.5*ny])
    end
end
%legend([p1,p2],'S-STBM : Y1','S-STBM : Y2')

jj=jj+1;
figure(jj)
meanvarSim=cell(length(model),length(model));
for k=1:length(model)
    for kk=1:length(model)
        
        subplot(length(model),length(model),kk+(k-1)*length(model),'align')
        meanvarSim{k,kk}=zeros(2*nx-1,1);
        for i=1:nbsim
            plot([-ny+1 :1: ny-1],VarSim{1,i}{k,kk}(:,ny),'Color',[0.9,0.9,0.9])
            hold on;
            meanvarSim{k,kk}=meanvarSim{k,kk}+VarSim{i}{k,kk}(:,ny)/nbsim;
        end
        
        if k==1 && kk==1
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],VarRefy{k},'k')
            hold on
            title('Cy_1_1')
        end
        if k==2 && kk==2
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],(beta(1))^2*VarRefy{k-1}+(1-(beta(1))^2)*VarRefy{k},'k')
            hold on
            title('Cy_2_2')
        end
        if k==1 && kk==2
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],beta(1)*VarRefyalphaP{1},'k')
            hold on
            title('Cy_1_2')
        end
        if k==2 && kk==1
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],beta(1)*VarRefyalphaM{1},'k')
            hold on
            title('Cy_2_1')
        end
        if k==3 && kk==3
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],beta(2)^2*VarRefy{1}+beta(3)^2*VarRefy{2}+(1-beta(2)^2-beta(3)^2)*VarRefy{3},'k')
            hold on
            title('Cy_3_3')
        end
        if k==1 && kk==3
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],(beta(2))*VarRefyalphaP{2},'k')
            hold on
            title('Cy_1_3')
        end
        if k==3 && kk==1
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],(beta(2))*VarRefyalphaM{2},'k')
            hold on
            title('Cy_3_1')
        end
        if k==2 && kk==3
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],beta(2)*beta(1)*VarRefyalphaP{4}+beta(3)*(1-(beta(1))^2)*VarRefyalphaP{3},'k')
            title('Cy_2_3')
        end
        if k==3 && kk==2
            plot([-ny+1 :1: ny-1],meanvarSim{k,kk},'*b');
            hold on
            plot([-ny+1 :1: ny-1],beta(2)*beta(1)*VarRefyalphaM{4}+beta(3)*(1-(beta(1))^2)*VarRefyalphaM{3},'k')
            title('Cy_3_2')
        end
        xlabel('Lag separation distance')
        ylabel('Variogram value')
        if k==kk
            ylim([0  1.5])
        else
            ylim([-0.25  0.75])
        end
        xlim([0  0.5*ny])
    end
end
sim=1;
for k=1:length(model)
    jj=jj+1;
    figure(jj)
    imagesc(reshape(Z{sim}(:,k),[nx,ny]))
    colorbar()
    caxis([-3 3])
    colormap summer
    set(gca,'YDir','normal')
    if k==1
        title('Simulation Z1')
    elseif k==2
        title('Simulation Z2')
    end
end

jj=jj+1;
figure(jj)
imagesc(reshape(zind(:,sim),[nx,ny]))
colorbar()
colormap summer
set(gca,'YDir','normal')
title('Facies field')



